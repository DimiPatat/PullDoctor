<#
.SYNOPSIS
    PullDoctor Phase-1 cleanup: removes build artifacts, dead code, and
    stray backup/duplicate files, and relocates the test suite into its
    own folder. Touches ZERO analyzer/report logic.

.WHAT THIS SCRIPT DOES
    1. Deletes __pycache__\           (compiled .pyc -- auto-regenerates)
    2. Deletes old\                   (superseded code, already replaced
                                        by root-level versions of the
                                        same filenames)
    3. Deletes stray backup/duplicate files:
         *.bak, *.old.json, *.old, and any "name (1).ext" duplicate
         uploads (e.g. "consumables.generated (1).json")
    4. Deletes root-level scratch/sample report output:
         fight_1_report.*, fight_2_report.*, mockup_fight_3_report.*
    5. Moves all root-level test_*.py files into a new tests\ folder

.WHAT THIS SCRIPT DELIBERATELY DOES NOT TOUCH
    - docs\reports\*.html   (your published GitHub Pages report history --
                             left alone; archive that separately/manually
                             if/when you want to prune it, since unlike
                             everything above, deleting these is NOT
                             reversible from regenerated output)
    - Any *.py file that isn't inside old\ or named test_*.py
    - Any *.generated.json file (the CURRENT, non-.bak, non-"(1)" ones)
    - .github\, requirements.txt, README.md, GITHUB_PAGES_SETUP.md,
      WCL_Log_Analyzer_Guide.pdf

.SAFETY MODEL
    Nothing is permanently deleted by Remove-Item. Every file this script
    touches is MOVED into a timestamped folder:

        _cleanup_trash\<yyyyMMdd_HHmmss>\...

    preserving relative paths, so if anything looks wrong afterward you
    can simply move files back out, or delete that one trash folder once
    you're confident everything is fine. Nothing is ever silently gone.

.USAGE
    Dry run first (default -- shows exactly what WOULD move, changes
    nothing):
        .\phase1_cleanup.ps1

    Actually perform the cleanup:
        .\phase1_cleanup.ps1 -Execute

    Run from the PullDoctor project root (same folder this script lives
    in, or pass -ProjectRoot explicitly):
        .\phase1_cleanup.ps1 -Execute -ProjectRoot "C:\Users\U10105316\Downloads\PullDoctor-main"
#>

[CmdletBinding()]
param(
    [switch]$Execute,
    [string]$ProjectRoot = (Get-Location).Path
)

$ErrorActionPreference = "Stop"
$DryRun = -not $Execute
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$trashRoot = Join-Path $ProjectRoot "_cleanup_trash\$timestamp"
$testsRoot = Join-Path $ProjectRoot "tests"

# Running tally for the summary at the end.
$stats = [ordered]@{
    "pycache_deleted"      = 0
    "old_folder_deleted"   = 0
    "bak_dup_deleted"      = 0
    "sample_reports_moved" = 0
    "tests_moved"          = 0
}

function Write-Action($msg) {
    $prefix = if ($DryRun) { "[DRY RUN]" } else { "[DOING]  " }
    Write-Host "$prefix $msg"
}

function Move-ToTrash {
    param(
        [Parameter(Mandatory)][string]$FullPath,
        [Parameter(Mandatory)][string]$ProjectRoot,
        [Parameter(Mandatory)][string]$TrashRoot
    )
    $relative = $FullPath.Substring($ProjectRoot.Length).TrimStart('\', '/')
    $destination = Join-Path $TrashRoot $relative
    Write-Action "trash: $relative"
    if (-not $DryRun) {
        $destDir = Split-Path $destination -Parent
        if (-not (Test-Path $destDir)) {
            New-Item -ItemType Directory -Path $destDir -Force | Out-Null
        }
        Move-Item -Path $FullPath -Destination $destination -Force
    }
}

Write-Host "=================================================================="
Write-Host " PullDoctor Phase-1 Cleanup"
Write-Host " Project root : $ProjectRoot"
Write-Host " Mode         : $(if ($DryRun) {'DRY RUN (no files will move)'} else {'EXECUTE (files will move to _cleanup_trash)'})"
Write-Host "=================================================================="
Write-Host ""

# ---------------------------------------------------------------------
# 1. __pycache__ folders (anywhere under the project, not just root)
# ---------------------------------------------------------------------
Write-Host "--- Step 1: __pycache__ folders ---"
$pycacheDirs = Get-ChildItem -Path $ProjectRoot -Recurse -Directory -Filter "__pycache__" -ErrorAction SilentlyContinue
foreach ($dir in $pycacheDirs) {
    $fileCount = (Get-ChildItem -Path $dir.FullName -File -Recurse -ErrorAction SilentlyContinue).Count
    Move-ToTrash -FullPath $dir.FullName -ProjectRoot $ProjectRoot -TrashRoot $trashRoot
    $stats["pycache_deleted"] += $fileCount
}
if ($pycacheDirs.Count -eq 0) { Write-Host "  (none found)" }
Write-Host ""

# ---------------------------------------------------------------------
# 2. old\ folder (entire folder, in one move)
# ---------------------------------------------------------------------
Write-Host "--- Step 2: old\ folder (superseded code) ---"
$oldFolder = Join-Path $ProjectRoot "old"
if (Test-Path $oldFolder) {
    $fileCount = (Get-ChildItem -Path $oldFolder -File -Recurse -ErrorAction SilentlyContinue).Count
    Move-ToTrash -FullPath $oldFolder -ProjectRoot $ProjectRoot -TrashRoot $trashRoot
    $stats["old_folder_deleted"] = $fileCount
} else {
    Write-Host "  (old\ not found -- already clean)"
}
Write-Host ""

# ---------------------------------------------------------------------
# 3. Stray backup / duplicate-upload files, root-level only
#    (*.bak, *.old.json, *.old, "name (1).ext")
# ---------------------------------------------------------------------
Write-Host "--- Step 3: backup / duplicate files ---"
$bakPatterns = @("*.bak", "*.old.json", "*.old")
$bakFiles = @()
foreach ($pattern in $bakPatterns) {
    $bakFiles += Get-ChildItem -Path $ProjectRoot -File -Filter $pattern -ErrorAction SilentlyContinue
}
# " (1)" duplicate-upload pattern, e.g. "consumables.generated (1).json"
$dupFiles = Get-ChildItem -Path $ProjectRoot -File -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -match '\s\(\d+\)\.' }
$bakFiles += $dupFiles

$bakFiles = $bakFiles | Sort-Object FullName -Unique
foreach ($f in $bakFiles) {
    Move-ToTrash -FullPath $f.FullName -ProjectRoot $ProjectRoot -TrashRoot $trashRoot
    $stats["bak_dup_deleted"] += 1
}
if ($bakFiles.Count -eq 0) { Write-Host "  (none found)" }
Write-Host ""

# ---------------------------------------------------------------------
# 4. Root-level scratch/sample report output
#    (fight_1_report.*, fight_2_report.*, mockup_fight_3_report.*)
# ---------------------------------------------------------------------
Write-Host "--- Step 4: root-level sample report output ---"
$sampleReportPatterns = @("fight_1_report.*", "fight_2_report.*", "mockup_fight_3_report.*")
$sampleFiles = @()
foreach ($pattern in $sampleReportPatterns) {
    $sampleFiles += Get-ChildItem -Path $ProjectRoot -File -Filter $pattern -ErrorAction SilentlyContinue
}
foreach ($f in $sampleFiles) {
    Move-ToTrash -FullPath $f.FullName -ProjectRoot $ProjectRoot -TrashRoot $trashRoot
    $stats["sample_reports_moved"] += 1
}
if ($sampleFiles.Count -eq 0) { Write-Host "  (none found)" }
Write-Host ""

# ---------------------------------------------------------------------
# 5. Move root-level test_*.py into tests\ (NOT trashed -- these are
#    real, valuable tests, just relocated).
# ---------------------------------------------------------------------
Write-Host "--- Step 5: relocate test_*.py -> tests\ ---"
$testFiles = Get-ChildItem -Path $ProjectRoot -File -Filter "test_*.py" -ErrorAction SilentlyContinue
if ($testFiles.Count -gt 0 -and -not (Test-Path $testsRoot) -and -not $DryRun) {
    New-Item -ItemType Directory -Path $testsRoot -Force | Out-Null
}
foreach ($f in $testFiles) {
    $destination = Join-Path $testsRoot $f.Name
    Write-Action "move to tests\: $($f.Name)"
    if (-not $DryRun) {
        Move-Item -Path $f.FullName -Destination $destination -Force
    }
    $stats["tests_moved"] += 1
}
if ($testFiles.Count -eq 0) { Write-Host "  (none found)" }
Write-Host ""

# ---------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------
Write-Host "=================================================================="
Write-Host " SUMMARY"
Write-Host "=================================================================="
Write-Host ("  __pycache__ files removed   : {0}" -f $stats["pycache_deleted"])
Write-Host ("  old\ files removed          : {0}" -f $stats["old_folder_deleted"])
Write-Host ("  backup/duplicate files removed : {0}" -f $stats["bak_dup_deleted"])
Write-Host ("  sample reports removed      : {0}" -f $stats["sample_reports_moved"])
Write-Host ("  tests moved to tests\       : {0}" -f $stats["tests_moved"])
$totalTouched = ($stats.Values | Measure-Object -Sum).Sum
Write-Host ("  TOTAL FILES TOUCHED         : {0}" -f $totalTouched)
Write-Host ""
if ($DryRun) {
    Write-Host "This was a DRY RUN -- nothing was moved or deleted."
    Write-Host "Re-run with -Execute to actually perform the cleanup:"
    Write-Host "    .\phase1_cleanup.ps1 -Execute"
} else {
    Write-Host "Done. Anything removed is sitting in (not deleted, just moved):"
    Write-Host "    $trashRoot"
    Write-Host "Once you've confirmed everything still runs correctly, you can"
    Write-Host "delete that folder (or the whole _cleanup_trash\ directory) for good."
    Write-Host ""
    Write-Host "NOTE: main.py / generate_html_report.py imports may reference"
    Write-Host "test_*.py indirectly via a test runner config (pytest.ini,"
    Write-Host "tox.ini, etc.) -- if you have one, update its test path from"
    Write-Host "'.' to 'tests\' after this move."
}
Write-Host "=================================================================="
